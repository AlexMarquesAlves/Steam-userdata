name = "Traducao Portugues (BR)"
description = "Traducao Don't Starve Together para Portugues"
author = "BeetlejuiceBr"
version = "437028"

forumthread = ""

api_version = 4

dont_starve_compatible = true
reign_of_giants_compatible = true
dst_compatible = true
all_clients_require_mod=false
client_only_mod=true

-- Can specify a custom icon for this mod!
icon_atlas = "modicon.xml"
icon = "modicon.tex"




configuration_options =
{
    {
        name = "Linguagem",
        options =
        {
            {description = "Portugues", data = "BrazilianLanguagePack.po"},
        },
        default = "BrazilianLanguagePack.po"
    },
}
