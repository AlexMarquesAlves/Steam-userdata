local language_str = GetModConfigData("Linguagem")

LoadPOFile(language_str, "")